#include "VfsFile.h"
#include "VfsFileInfo.h"

VfsFile::VfsFile(char*){

}

void VfsFile::exportfile(std::string external_path){

}

void VfsFile::saveInVfs(std::fstream& repository, int offset){

}
